
import mysql from 'mysql2/promise';

export const db = mysql.createPool({
  host: 'localhost',
  user: 'root',          // Ensure this is the correct user
  password: 'Mysql@123', // Ensure this is correct
  database: 'mydatabase'
});



export const initializeDB = async () => {
  try {
    // Create Users Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    password VARCHAR(255) NOT NULL,
    phone_number VARCHAR(15),
    additional_number VARCHAR(15),
    email VARCHAR(255),
    gender VARCHAR(50),
    role VARCHAR(10),
    address VARCHAR(500),
    city VARCHAR(10),
    aadhar_no VARCHAR(20),
    aadhar_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
    `);
    console.log("✅ Users table is ready!");

    // Create Blogs Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS blogs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        blogTitle VARCHAR(255) NOT NULL,
        blogContent TEXT NOT NULL,
        blogCategory VARCHAR(255) NOT NULL,
        blogSubcategory VARCHAR(255) NOT NULL,
        blogCatID INT NOT NULL,
        slug VARCHAR(255) NOT NULL UNIQUE,  -- Added slug column
        blogSubCatID INT NOT NULL,
        imagesArray JSON DEFAULT NULL, -- Explicitly allows NULL
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log("✅ Blogs table is ready!");

    await db.query(`
    CREATE TABLE IF NOT EXISTS subCategoryInfo(
      id INT AUTO_INCREMENT PRIMARY KEY,
      subCategoryTitle VARCHAR(255) NOT NULL,
      subCategoryContent TEXT NOT NULL,
      categoryName VARCHAR(255) NOT NULL,
      subCategoryName VARCHAR(255) NOT NULL,
      categoryId INT NOT NULL,
      subCategoryId INT NOT NULL,
      slug VARCHAR(255) NOT NULL UNIQUE,
      imagesArray JSON DEFAULT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
     `);
    console.log("✅ Subcatinfo table is ready!");


    await db.query(`
      CREATE TABLE IF NOT EXISTS categories (
       id INT AUTO_INCREMENT PRIMARY KEY,
        categoryName VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log("✅ Category table is ready!");

    await db.query(`
      CREATE TABLE IF NOT EXISTS subcategories (
      id INT AUTO_INCREMENT PRIMARY KEY,
      categoryId INT NOT NULL,
      categoryName VARCHAR(255) NOT NULL,
      subCategoryName VARCHAR(255) NOT NULL,
      FOREIGN KEY (categoryId) REFERENCES categories(id) ON DELETE CASCADE
      )
    `);
    console.log("✅ subcategories table is ready!");

    await db.query(`
      CREATE TABLE IF NOT EXISTS faqs (
       id INT AUTO_INCREMENT PRIMARY KEY,
        question TEXT,
        answer TEXT,
        categoryId INT NOT NULL,
        categoryName VARCHAR(255) NOT NULL,
        subcategoryId INT NOT NULL,
        subCategoryName VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log("✅ faq table is ready!");

    await db.query(`
       CREATE TABLE IF NOT EXISTS appointments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        fullName VARCHAR(100) NOT NULL,
        doctorName VARCHAR(100) NOT NULL,
        mobileNumber VARCHAR(15) NOT NULL,
        email VARCHAR(100) NOT NULL,
        message TEXT,
        date DATE NOT NULL,
        time TIME NOT NULL,
        isOnline BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`
    )
    console.log("✅ appointments table is ready!");



    await db.query(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        reviewType ENUM('text', 'video') NOT NULL,
        videoUrl TEXT,
        reviewText TEXT,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        createdBy VARCHAR(255),
        rating DECIMAL(2,1) CHECK (rating >= 0 AND rating <= 5),
        reviewerName VARCHAR(255) NOT NULL
      )
    `);
    console.log("✅ reviews table (unified) is ready!");


    // await db.query(`
    //   CREATE TABLE roleaccess (
    //     id INT AUTO_INCREMENT PRIMARY KEY,
    //     role VARCHAR(50) NOT NULL,
    //     module VARCHAR(100) NOT NULL,
    //     can_read BOOLEAN NOT NULL DEFAULT FALSE,
    //     can_write BOOLEAN NOT NULL DEFAULT FALSE,
    //     can_delete BOOLEAN NOT NULL DEFAULT FALSE,
    //     can_all BOOLEAN NOT NULL DEFAULT FALSE,
    //     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    //     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    //     UNIQUE KEY uniq_role_module (role, module)
    //   )
    // `);
    // console.log("✅ faq table is ready!");






  } catch (error) {
    console.error("❌ Error initializing database:", error);
  }
};


// Run the function when the app starts
initializeDB();