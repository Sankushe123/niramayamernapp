import { db } from "../../config/dbConfig";

// export async function GET(req) {
//   try {
//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     const title = searchParams.get("blogTitle");

//     console.log("Requested ID:", id, "Title:", title);

//     if (id) {
//       const blog = await getSingleBlogById(parseInt(id, 10));
//       if (!blog) return Response.json({ message: "Blog not found" }, { status: 404 });
//       return Response.json(blog, { status: 200 });
//     }

//     if (title) {
//       const blog = await getSingleBlogByTitle(title);
//       if (!blog) return Response.json({ message: "Blog not found" }, { status: 404 });
//       return Response.json(blog, { status: 200 });
//     }

//     return Response.json(await getAllBlogs(), { status: 200 });
//   } catch (error) {
//     console.error("❌ Error fetching blog:", error);
//     return Response.json({ message: "Internal Server Error" }, { status: 500 });
//   }
// }
export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const slug = searchParams.get("slug"); // Use slug instead of blogTitle

    console.log("Requested ID:", id);

    // Get by ID
    if (id) {
      const blog = await getSingleBlogBySlug(id);
      if (!blog) {
        return Response.json({ message: "Blog not found" }, { status: 404 });
      }
      return Response.json(blog, { status: 200 });
    }

    // Get by Slug
    // if (slug) {
    //   const blog = await getSingleBlogBySlug(slug); // You must create this function
    //   if (!blog) {
    //     return Response.json({ message: "Blog not found" }, { status: 404 });
    //   }
    //   return Response.json(blog, { status: 200 });
    // }

    // Return all blogs if no ID or slug provided
    const blogs = await getAllBlogs();
    return Response.json(blogs, { status: 200 });

  } catch (error) {
    console.error("❌ Error fetching blog:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}



export async function POST(req) {
  try {
    const body = await req.json();
    const newBlog = await createBlog(body);
    return Response.json(newBlog, { status: 201 });
  } catch (error) {
    console.error("❌ Error creating blog:", error);
    return Response.json({ message: "Failed to create blog" }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    const body = await req.json();

    console.log('req', req)
    if (isNaN(id)) return Response.json({ message: "Invalid Blog ID" }, { status: 400 });

    const updatedBlog = await updateBlog(id, body);
    return Response.json(updatedBlog, { status: 200 });
  } catch (error) {
    console.error("❌ Error updating blog:", error);
    return Response.json({ message: "Failed to update blog" }, { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get("slug"); // ✅ use slug instead of id

    if (!slug) {
      return Response.json({ message: "Missing slug" }, { status: 400 });
    }

    await deleteBlog(slug);
    return Response.json({ message: "Blog deleted successfully" }, { status: 200 });
  } catch (error) {
    console.error("❌ Error deleting blog:", error);
    return Response.json({ message: "Failed to delete blog" }, { status: 500 });
  }
}

const getAllBlogs = async () => {
  const [rows] = await db.query("SELECT * FROM blogs");

  return rows.map((blog) => ({
    ...blog,
  }));
};


const getSingleBlog = async (id) => {
  console.log("Fetching blog with ID:", id);

  const [rows] = await db.query("SELECT * FROM blogs WHERE id = ?", [id]);

  console.log("DB Response:", rows);

  if (rows.length === 0) return null;

  return {
    ...rows[0],
    imagesArray: rows[0].imagesArray || [], // No need to JSON.parse
  };
};


import slugify from "slugify";

const createBlog = async ({
  blogTitle,
  blogContent,
  blogCategory,
  blogSubcategory,
  blogCatID,
  blogSubCatID,
  imagesArray,
}) => {
  const slug = slugify(blogTitle, { lower: true, strict: true }); // e.g., "Winter Care Tips" -> "winter-care-tips"

  const [result] = await db.query(
    "INSERT INTO blogs (blogTitle, slug, blogContent, blogCategory, blogSubcategory, blogCatID, blogSubCatID, imagesArray) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
    [
      blogTitle,
      slug,
      blogContent,
      blogCategory,
      blogSubcategory,
      blogCatID,
      blogSubCatID,
      imagesArray.length > 0 ? JSON.stringify(imagesArray) : null,
    ]
  );

  return {
    id: result.insertId,
    blogTitle,
    slug,
    blogContent,
  };
};


const updateBlog = async (id, { blogTitle, blogContent }) => {
  const slug = slugify(blogTitle, { lower: true, strict: true });

  await db.query(
    "UPDATE blogs SET blogTitle = ?, slug = ?, blogContent = ? WHERE id = ?",
    [blogTitle, slug, blogContent, id]
  );

  return { id, blogTitle, slug, blogContent };
};

const deleteBlog = async (slug) => {
  await db.query("DELETE FROM blogs WHERE slug = ?", [slug]);
  return { message: "Blog deleted successfully" };
};


const getSingleBlogBySlug = async (slug) => {
  const [rows] = await db.query("SELECT * FROM blogs WHERE slug = ?", [slug]);

  if (rows.length === 0) return null;

  return {
    ...rows[0],
    imagesArray: rows[0].imagesArray || [],
  };
};

