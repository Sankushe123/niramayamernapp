import { db } from "../../config/dbConfig";
import bcrypt from "bcryptjs";
import { NextResponse } from 'next/server';
export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      const user = await getSingleUser(parseInt(id, 10));
      if (!user) return Response.json({ message: "User not found" }, { status: 404 });
      return Response.json(user, { status: 200 });
    }

    return Response.json(await getAllUsers(), { status: 200 });
  } catch (error) {
    console.error("❌ Error fetching user:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const body = await req.json(); // ✅ Fixed async issue
    const newUser = await createUser(body);
    return Response.json(newUser, { status: 201 });
  } catch (error) {
    console.error("❌ Error creating user:", error);
    return Response.json({ message: "Failed to create user" }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id || isNaN(Number(id))) return Response.json({ message: "Invalid User ID" }, { status: 400 });

    const body = await req.json(); // ✅ Fixed async issue
    const updatedUser = await updateUser(parseInt(id, 10), body);
    return Response.json(updatedUser, { status: 200 });
  } catch (error) {
    console.error("❌ Error updating user:", error);
    return Response.json({ message: "Failed to update user" }, { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id || isNaN(Number(id))) return Response.json({ message: "Invalid User ID" }, { status: 400 });

    await deleteUser(parseInt(id, 10));
    return Response.json({ message: "User deleted successfully" }, { status: 200 });
  } catch (error) {
    console.error("❌ Error deleting user:", error);
    return Response.json({ message: "Failed to delete user" }, { status: 500 });
  }
}

// Database Queries
const getAllUsers = async () => {
  const [rows] = await db.query("SELECT * FROM users");
  return rows;
};

const getSingleUser = async (id) => {
  const [rows] = await db.query("SELECT * FROM users WHERE id = ?", [id]);
  return rows.length ? rows[0] : null;
};

const createUser = async ({
  first_name,
  last_name,
  phone_number,
  additional_number,
  email,
  gender,
  address,
  city,
  password,
  aadhar_no,
  aadhar_image,
  role,
}) => {
  try {
  

    console.log("Executing Query:", {
      first_name,
      last_name,
      phone_number,
      additional_number,
      email,
      gender,
      address,
      city,
      password,
      aadhar_no,
      aadhar_image: aadhar_image ? JSON.stringify(aadhar_image) : null,
      role,
    });
    
    
    // Ensure db.query() is properly awaited
    const [result] = await db.query(
      `INSERT INTO users 
        (first_name, last_name, phone_number, additional_number, email, gender, address, city, password, aadhar_no, aadhar_image, role) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        first_name,
        last_name,
        phone_number,
        additional_number,
        email,
        gender ? gender : null,
        address,
        city,
        password,
        aadhar_no,
        aadhar_image ? JSON.stringify(aadhar_image) : null, 
        role,
      ]
    );

    return { id: result.insertId, first_name, last_name, email };
  } catch (error) {
    console.error("❌ Error creating user:", error);
    throw new Error("Failed to create user");
  }
};


const updateUser = async (id, {
  first_name,
  last_name,
  phone_number,
  additional_number,
  email,
  gender,
  address,
  city,
  password,
  aadhar_no,
  aadhar_image,
  role,
}) => {
  try {
    await db.query(
      `UPDATE users 
       SET first_name = ?, last_name = ?, phone_number = ?, additional_number = ?, email = ?, gender = ?, address = ?, city = ?, password = ?, aadhar_no = ?, aadhar_image = ?, role = ? 
       WHERE id = ?`,
      [
        first_name,
        last_name,
        phone_number,
        additional_number,
        email,
        gender,
        address,
        city,
        password,
        aadhar_no,
        aadhar_image ? JSON.stringify(aadhar_image) : null,
        role,
        id,
      ]
    );

    return { id, first_name, last_name, phone_number, email, gender, address };
  } catch (error) {
    console.error("❌ Error updating user:", error);
    throw new Error("Failed to update user");
  }
};

const deleteUser = async (id) => {
  try {
    await db.query("DELETE FROM users WHERE id = ?", [id]);
    return { message: "User deleted successfully" };
  } catch (error) {
    console.error("❌ Error deleting user:", error);
    throw new Error("Failed to delete user");
  }
};
