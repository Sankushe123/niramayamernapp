import { db } from "../../config/dbConfig";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import nodemailer from "nodemailer";

// JWT Secret
const JWT_SECRET = "your_secret_key"; // Change this to a secure key

export async function REGISTER(req) {
    try {
        const {
            first_name, last_name, phone_number, additional_number, email,
            gender, address, city, password, aadhar_no, aadhar_image, role
        } = await req.json();

        // Check if user already exists
        const [existingUser] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
        if (existingUser.length) {
            return Response.json({ message: "Email already registered" }, { status: 400 });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert new user
        const [result] = await db.query(
            `INSERT INTO users (first_name, last_name, phone_number, additional_number, email, gender, address, city, password, aadhar_no, aadhar_image, role) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [first_name, last_name, phone_number, additional_number, email, gender, address, city, hashedPassword, aadhar_no, aadhar_image ? JSON.stringify(aadhar_image) : null, role]
        );

        return Response.json({ id: result.insertId, first_name, last_name, email }, { status: 201 });

    } catch (error) {
        console.error("❌ Error registering user:", error);
        return Response.json({ message: "Failed to register user" }, { status: 500 });
    }
}

export async function LOGIN(req) {
    try {
        const { email, password } = await req.json();

        // Find user by email
        const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
        if (!rows.length) {
            return Response.json({ message: "User not found" }, { status: 404 });
        }

        const user = rows[0];

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return Response.json({ message: "Invalid credentials" }, { status: 401 });
        }

        // Generate JWT token
        const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "1h" });

        return Response.json({ message: "Login successful", token }, { status: 200 });

    } catch (error) {
        console.error("❌ Error during login:", error);
        return Response.json({ message: "Login failed" }, { status: 500 });
    }
}

import crypto from "crypto";

const otpStore = new Map();

export async function SEND_OTP(req) {
    try {
        const { email } = await req.json();

        // Check if user exists
        const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
        if (!rows.length) {
            return Response.json({ message: "User not found" }, { status: 404 });
        }

        // Generate OTP (6-digit random number)
        const otp = crypto.randomInt(100000, 999999).toString();

        // Store OTP with expiration time (5 minutes)
        otpStore.set(email, { otp, expiresAt: Date.now() + 5 * 60 * 1000 });

        // Send OTP via email
        await sendEmail(email, `Your OTP Code is: ${otp}`);

        return Response.json({ message: "OTP sent successfully" }, { status: 200 });

    } catch (error) {
        console.error("❌ Error sending OTP:", error);
        return Response.json({ message: "Failed to send OTP" }, { status: 500 });
    }
}


export async function VERIFY_OTP(req) {
    try {
        const { email, otp } = await req.json();

        // Check if OTP exists and is valid
        const storedOtp = otpStore.get(email);
        if (!storedOtp || storedOtp.otp !== otp || storedOtp.expiresAt < Date.now()) {
            return Response.json({ message: "Invalid or expired OTP" }, { status: 400 });
        }

        // Remove OTP from store after verification
        otpStore.delete(email);

        return Response.json({ message: "OTP verified successfully" }, { status: 200 });

    } catch (error) {
        console.error("❌ Error verifying OTP:", error);
        return Response.json({ message: "OTP verification failed" }, { status: 500 });
    }
}


export function authenticateToken(req, res, next) {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) {
        return Response.json({ message: "Access denied" }, { status: 401 });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return Response.json({ message: "Invalid token" }, { status: 403 });
    }
}



