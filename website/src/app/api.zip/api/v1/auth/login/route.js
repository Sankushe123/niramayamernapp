import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "../../../config/dbConfig"; // Assuming a database connection file
const JWT_SECRET = process.env.NEXT_PUBLIC_JWTKEY;

export async function POST(req) {
  try {
    console.log('hello login ');
    // LOGIN returns a Response, so just return it
    return await LOGIN(req);
  } catch (error) {
    console.error("❌ Error logging in:", error);
    return new Response(JSON.stringify({ message: "Login failed" }), { status: 500 });
  }
}


async function LOGIN(req) {
  try {
    const { email, password } = await req.json();

    console.log('Received Email:', email);
    console.log('Received Password:', password);

    // Find user by email
    const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);

    if (!rows || rows.length === 0) {
      console.log("❌ User not found");
      return new Response(JSON.stringify({ message: "User not found" }), { status: 404 });
    }

    const user = rows[0];
    if (!user.password) {
      return new Response(JSON.stringify({ message: "Invalid credentials" }), { status: 401 });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return new Response(JSON.stringify({ message: "Invalid credentials" }), { status: 401 });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: "1h" }
    );

    return new Response(JSON.stringify({
      message: "Login successful", 
      token, 
      user: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        role: user.role,
      },
    }), { status: 200 });

  } catch (error) {
    console.error("❌ Error during login:", error);
    return new Response(JSON.stringify({ message: "Login failed" }), { status: 500 });
  }
}

