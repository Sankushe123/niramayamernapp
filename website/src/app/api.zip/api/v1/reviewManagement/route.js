import { db } from "../../config/dbConfig";

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      const review = await getSingleReview(parseInt(id, 10));
      if (!review) return Response.json({ message: "Review not found" }, { status: 404 });
      return Response.json(review, { status: 200 });
    }

    return Response.json(await getAllReviews(), { status: 200 });
  } catch (error) {
    console.error("❌ Error fetching reviews:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req) {
  try {

    console.log('hello world')
    const body = await req.json();
    console.log('body',body);
    
    const newReview = await createReview(body);
    return Response.json(newReview, { status: 201 });
  } catch (error) {
    console.error("❌ Error creating review:", error);
    return Response.json({ message: "Failed to create review" }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const body = await req.json();

    if (isNaN(id)) return Response.json({ message: "Invalid Review ID" }, { status: 400 });

    const updatedReview = await updateReview(id, body);
    return Response.json(updatedReview, { status: 200 });
  } catch (error) {
    console.error("❌ Error updating review:", error);
    return Response.json({ message: "Failed to update review" }, { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (isNaN(id)) return Response.json({ message: "Invalid Review ID" }, { status: 400 });

    await deleteReview(id);
    return Response.json({ message: "Review deleted successfully" }, { status: 200 });
  } catch (error) {
    console.error("❌ Error deleting review:", error);
    return Response.json({ message: "Failed to delete review" }, { status: 500 });
  }
}

const getAllReviews = async () => {
  const [rows] = await db.query("SELECT * FROM reviews ORDER BY createdAt DESC");
  return rows;
};

const getSingleReview = async (id) => {
  const [rows] = await db.query("SELECT * FROM reviews WHERE id = ?", [id]);
  if (rows.length === 0) return null;
  return rows[0];
};

const createReview = async ({ reviewType, videoUrl = null, reviewText = null, rating, reviewerName, createdBy }) => {
  const [result] = await db.query(
    `INSERT INTO reviews (reviewType, videoUrl, reviewText, rating, reviewerName, createdBy) VALUES (?, ?, ?, ?, ?, ?)`,
    [reviewType, videoUrl, reviewText, rating, reviewerName, createdBy]
  );
  return { id: result.insertId, reviewType, videoUrl, reviewText, createdBy, rating, reviewerName };
};


const updateReview = async (id, { reviewType, videoUrl = null, reviewText = null, createdBy, rating, reviewerName }) => {
  await db.query(
    `UPDATE reviews SET reviewType = ?, videoUrl = ?, reviewText = ?, createdBy = ?, rating = ?, reviewerName = ? WHERE id = ?`,
    [reviewType, videoUrl, reviewText, createdBy, rating, reviewerName, id]
  );
  return { id, reviewType, videoUrl, reviewText, createdBy, rating, reviewerName };
};

const deleteReview = async (id) => {
  await db.query("DELETE FROM reviews WHERE id = ?", [id]);
  return { message: "Review deleted successfully" };
};
