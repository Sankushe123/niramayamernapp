import { db } from "../../../config/dbConfig";

function formatDateToYYYYMMDD(dateStr) {
  const date = new Date(dateStr);
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

export async function GET(req) {
  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");

    if (id) {
      const [appointment] = await db.query("SELECT * FROM appointments WHERE id = ?", [id]);
      if (appointment.length === 0) {
        return Response.json({ message: "Appointment not found" }, { status: 404 });
      }
      return Response.json(appointment[0], { status: 200 });
    }

    // No ID: fetch all future and today’s appointments
    const [appointments] = await db.query("SELECT * FROM appointments ORDER BY created_at DESC");

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const result = {};

    for (const appt of appointments) {
      const dateObj = new Date(appt.date);
      if (dateObj >= today) {
        const dateStr = formatDateToYYYYMMDD(dateObj);
        const timeStr = appt.time?.slice(0, 5); // 'HH:mm'
        if (!result[dateStr]) result[dateStr] = [];
        result[dateStr].push(timeStr);
      }
    }

    return Response.json(result, { status: 200 });

  } catch (error) {
    console.error("❌ Error fetching appointments:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}
