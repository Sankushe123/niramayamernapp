import { db } from "../../config/dbConfig";
import { sendEmail } from '@/app/api/utils/sendEmail';



function formatDate(inputDate) {
  const date = new Date(inputDate);
  const options = { year: 'numeric', month: 'long', day: '2-digit' };
  return date.toLocaleDateString('en-GB', options); // 'en-GB' gives "01 May 2025" format
}

function formatDateToYYYYMMDD(dateStr) {
  const date = new Date(dateStr);
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

export async function POST(req) {
  try {
    const body = await req.json();
    const { fullName, mobileNumber, email, message, date, time, isOnline, doctorName } = body;

    console.log('body ===>', body);

    if (!fullName || !mobileNumber || !email || !date || !time || !doctorName) {
      return Response.json({ message: "Missing required fields" }, { status: 400 });
    }

    const selectedDate = new Date(date);
    selectedDate.setDate(selectedDate.getDate() + 0);

    const formattedDate1 =
      selectedDate.getFullYear() +
      '-' +
      String(selectedDate.getMonth() + 1).padStart(2, '0') +
      '-' +
      String(selectedDate.getDate()).padStart(2, '0');

    // Insert into DB (include isOnline)
    const [result] = await db.query(
      `INSERT INTO appointments (fullName, mobileNumber, email, message, date, time, isOnline, doctorName)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        fullName,
        mobileNumber,
        email,
        message || "",
        formattedDate1,
        time,
        isOnline ?? false, 
        doctorName,
      ]
    );

    const formattedDate = formatDate(date);

    // ✅ Send Email Notification
    const sendEmailResult = await sendEmail({
      to: email,
      subject: "Your Appointment Confirmation",
      html: `
        <h2>Hello ${fullName},</h2>
        <p>Your appointment has been successfully scheduled on <strong>${formattedDate}</strong> at <strong>${time}</strong>.</p>
        <p>We'll contact you shortly. Thank you!</p>
      `,
      purpose: "Appointment",
      userDetails: { fullName, email, mobileNumber, message, formattedDate, time, isOnline, doctorName }
    });

    console.log("Email sent result:", sendEmailResult);

    return Response.json(
      { message: "Appointment created successfully", appointmentId: result.insertId },
      { status: 201 }
    );

  } catch (error) {
    console.error("❌ Error creating appointment:", error);
    return Response.json({ message: "Failed to create appointment" }, { status: 500 });
  }
}


export async function GET(req) {
  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");

    if (!id) {
      // No 'id' parameter, fetch all appointments
      const [appointments] = await db.query("SELECT * FROM appointments ORDER BY created_at DESC");

      const formattedAppointments = appointments.map(appt => ({
        ...appt,
        date: formatDateToYYYYMMDD(appt.date),
      }));

      return Response.json(formattedAppointments, { status: 200 });
    }

    const [appointment] = await db.query("SELECT * FROM appointments WHERE id = ?", [id]);
    if (appointment.length === 0) {
      return Response.json({ message: "Appointment not found" }, { status: 404 });
    }

    const formattedAppointment = {
      ...appointment[0],
      date: formatDateToYYYYMMDD(appointment[0].date),
    };

    return Response.json(formattedAppointment, { status: 200 });

  } catch (error) {
    console.error("❌ Error fetching appointments:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");

    if (!id) {
      return Response.json({ message: "Missing 'id' parameter" }, { status: 400 });
    }

    const body = await req.json();
    const { fullName, mobileNumber, email, message, date, time, isOnline, doctorName } = body;

    if (!fullName || !mobileNumber || !email || !date || !time || !doctorName) {
      return Response.json({ message: "Missing required fields" }, { status: 400 });
    }

    // Format date manually to 'YYYY-MM-DD'
    const selectedDate = new Date(date);
    const formattedDate =
      selectedDate.getFullYear() +
      '-' +
      String(selectedDate.getMonth() + 1).padStart(2, '0') +
      '-' +
      String(selectedDate.getDate()).padStart(2, '0');

    const formattedTime = time;

    // Update the appointment with the provided ID
    const [result] = await db.query(
      `UPDATE appointments 
       SET fullName = ?, mobileNumber = ?, email = ?, message = ?, date = ?, time = ?, isOnline = ?, doctorName = ? 
       WHERE id = ?`,
      [
        fullName,
        mobileNumber,
        email,
        message || "",
        formattedDate,
        formattedTime,
        isOnline ?? false,
        doctorName,
        id
      ]
    );

    if (result.affectedRows === 0) {
      return Response.json({ message: "Appointment not found" }, { status: 404 });
    }

    return Response.json({ message: "Appointment updated successfully" }, { status: 200 });

  } catch (error) {
    console.error("❌ Error updating appointment:", error);
    return Response.json({ message: "Failed to update appointment" }, { status: 500 });
  }
}


// export async function DELETE(req) {
//   try {
//     const url = new URL(req.url);
//     const id = url.searchParams.get("id");

//     if (!id) {
//       return Response.json({ message: "Missing 'id' parameter" }, { status: 400 });
//     }


//     // Delete the appointment with the provided ID
//     const [result] = await db.query("DELETE FROM appointments WHERE id = ?", [id]);

//     if (result.affectedRows === 0) {
//       return Response.json({ message: "Appointment not found" }, { status: 404 });
//     }

//     return Response.json({ message: "Appointment deleted successfully" }, { status: 200 });

//   } catch (error) {
//     console.error("❌ Error deleting appointment:", error);
//     return Response.json({ message: "Failed to delete appointment" }, { status: 500 });
//   }
// }

export async function DELETE(req) {
  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");

    if (id) {
      // Delete a specific appointment by ID
      const [result] = await db.query("DELETE FROM appointments WHERE id = ?", [id]);

      if (result.affectedRows === 0) {
        return Response.json({ message: "Appointment not found" }, { status: 404 });
      }

      return Response.json({ message: "Appointment deleted successfully" }, { status: 200 });
    } else {
      // Delete all appointments
      const [result] = await db.query("DELETE FROM appointments");

      return Response.json({ message: "All appointments deleted successfully" }, { status: 200 });
    }

  } catch (error) {
    console.error("❌ Error deleting appointment(s):", error);
    return Response.json({ message: "Failed to delete appointment(s)" }, { status: 500 });
  }
}

