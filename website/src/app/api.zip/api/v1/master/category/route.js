import { db } from "./../../../config/dbConfig";

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      const category = await getSingleCategory(parseInt(id, 10));
      if (!category) return Response.json({ message: "Category not found" }, { status: 404 });
      return Response.json(category, { status: 200 });
    }

    return Response.json(await getAllCategories(), { status: 200 });
  } catch (error) {
    console.error("❌ Error fetching category:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req) {
  try {

    console.log('req',req)

    const body = await req.json();
    const newCategory = await createCategory(body);
    return Response.json(newCategory, { status: 201 }) ;
  } catch (error) {
    console.error("❌ Error creating category:", error);
    return Response.json({ message: "Failed to create category" }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const body = await req.json();

    if (isNaN(id)) return Response.json({ message: "Invalid Category ID" }, { status: 400 });

    const updatedCategory = await updateCategory(id, body);
    return Response.json(updatedCategory, { status: 200 });
  } catch (error) {
    console.error("❌ Error updating category:", error);
    return Response.json({ message: "Failed to update category" }, { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (isNaN(id)) return Response.json({ message: "Invalid Category ID" }, { status: 400 });

    await deleteCategory(id);
    return Response.json({ message: "Category deleted successfully" }, { status: 200 });
  } catch (error) {
    console.error("❌ Error deleting category:", error);
    return Response.json({ message: "Failed to delete category" }, { status: 500 });
  }
}

const getAllCategories = async () => {
  const [rows] = await db.query("SELECT * FROM categories");
  return rows;
};

const getSingleCategory = async (id) => {
  const [rows] = await db.query("SELECT * FROM categories WHERE id = ?", [id]);
  if (rows.length === 0) return null;
  return rows[0];
};

const createCategory = async ({ categoryName }) => {
  const [result] = await db.query("INSERT INTO categories (categoryName) VALUES (?)", [categoryName]);
  return { id: result.insertId, categoryName };
};

const updateCategory = async (id, { categoryName }) => {
  await db.query("UPDATE categories SET categoryName = ? WHERE id = ?", [categoryName, id]);
  return { id, categoryName };
};

const deleteCategory = async (id) => {
  await db.query("DELETE FROM categories WHERE id = ?", [id]);
  return { message: "Category deleted successfully" };
};
