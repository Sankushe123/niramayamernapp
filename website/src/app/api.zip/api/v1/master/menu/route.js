import { db } from "./../../../config/dbConfig";

export async function GET(req) {
  try {
    const menuData = await getMenuStructure();
    return Response.json(menuData, { status: 200 });
  } catch (error) {
    console.error("❌ Error generating menu structure:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}

const getMenuStructure = async () => {
  const [rows] = await db.query(`
    SELECT 
      c.id AS categoryId,
      c.categoryName,
      s.id AS subCategoryId,
      s.subCategoryName
    FROM categories c
    LEFT JOIN subcategories s ON s.categoryId = c.id
    ORDER BY c.categoryName, s.subCategoryName
  `);

  const menuMap = new Map();

  for (const row of rows) {
    const categoryTitle = row.categoryName;
    const subCategoryName = row.subCategoryName;

    if (!menuMap.has(categoryTitle)) {
      menuMap.set(categoryTitle, []);
    }

    if (subCategoryName) {
      const slug = `/services/${slugify(categoryTitle)}/${slugify(subCategoryName)}`;
      menuMap.get(categoryTitle).push({ name: subCategoryName, slug });
    }
  }

  const menu = [];
  for (const [title, subLinks] of menuMap.entries()) {
    menu.push({ title, subLinks });
  }

  return menu;
};

function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\w\-]+/g, "")
    .replace(/\-\-+/g, "-");
}
