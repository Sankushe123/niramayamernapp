import { db } from "./../../../config/dbConfig";


export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const categoryId = searchParams.get("categoryId");

    if (id) {
      const subCategory = await getSingleSubCategory(parseInt(id, 10));
      if (!subCategory) return Response.json({ message: "Subcategory not found" }, { status: 404 });
      return Response.json(subCategory, { status: 200 });
    }

    if (categoryId) {
      const subCategories = await getSubCategoriesByCategory(parseInt(categoryId, 10));
      if (subCategories.length === 0) 
        return Response.json({ message: "No subcategories found" }, { status: 404 });
      return Response.json(subCategories, { status: 200 });
    }

    return Response.json(await getAllSubCategories(), { status: 200 });
  } catch (error) {
    console.error("❌ Error fetching subcategory:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const newSubCategory = await createSubCategory(body);
    return Response.json(newSubCategory, { status: 201 });
  } catch (error) {
    console.error("❌ Error creating subcategory:", error);
    return Response.json({ message: "Failed to create subcategory" }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (isNaN(Number(id))) return Response.json({ message: "Invalid Subcategory ID" }, { status: 400 });

    const body = await req.json();
    const updatedSubCategory = await updateSubCategory(parseInt(id, 10), body);
    return Response.json(updatedSubCategory, { status: 200 });
  } catch (error) {
    console.error("❌ Error updating subcategory:", error);
    return Response.json({ message: "Failed to update subcategory" }, { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (isNaN(Number(id))) return Response.json({ message: "Invalid Subcategory ID" }, { status: 400 });

    await deleteSubCategory(parseInt(id, 10));
    return Response.json({ message: "Subcategory deleted successfully" }, { status: 200 });
  } catch (error) {
    console.error("❌ Error deleting subcategory:", error);
    return Response.json({ message: "Failed to delete subcategory" }, { status: 500 });
  }
}


// Database Queries
const getAllSubCategories = async () => {
  const [rows] = await db.query(`
    SELECT subcategories.id, subcategories.subCategoryName, categories.categoryName 
    FROM subcategories 
    JOIN categories ON subcategories.categoryId = categories.id
  `);
  return rows;
};

const getSingleSubCategory = async (id) => {
  const [rows] = await db.query(`
    SELECT subcategories.id, subcategories.subCategoryName, categories.categoryName 
    FROM subcategories 
    JOIN categories ON subcategories.categoryId = categories.id
    WHERE subcategories.id = ?
  `, [id]);

  if (rows.length === 0) return null;
  return rows[0];
};

const createSubCategory = async ({ categoryId, categoryName, subCategoryName }) => {
  const [result] = await db.query("INSERT INTO subcategories (categoryId,categoryName, subCategoryName) VALUES (?,?, ?)", [categoryId, categoryName, subCategoryName]);
  return { id: result.insertId, categoryId, subCategoryName };
};

const updateSubCategory = async (id, { categoryId, categoryName, subCategoryName }) => {
  await db.query("UPDATE subcategories SET categoryId = ?,categoryName = ?, subCategoryName = ? WHERE id = ?", [categoryId, categoryName, subCategoryName, id]);
  return { id, categoryId, subCategoryName };
};

const deleteSubCategory = async (id) => {
  await db.query("DELETE FROM subcategories WHERE id = ?", [id]);
  return { message: "Subcategory deleted successfully" };
};

const getSubCategoriesByCategory = async (categoryId) => {
  const [rows] = await db.query(`
    SELECT subcategories.id, subcategories.subCategoryName, subcategories.categoryId, categories.categoryName
    FROM subcategories
    JOIN categories ON subcategories.categoryId = categories.id
    WHERE subcategories.categoryId = ?
  `, [categoryId]);

  return rows;
};
