// /api/sub-category-info/route.js or route.ts (Next.js API route)
import { db } from "../../config/dbConfig";
import slugify from "slugify";

// ========================== HANDLERS ==========================



export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const categorySlug = searchParams.get("categorySlug");
    const subcategorySlug = searchParams.get("subcategorySlug");

    // Log all incoming query values
    console.log('Incoming Query Params:', { categorySlug, subcategorySlug });

    if (categorySlug && subcategorySlug) {
      const SubCategoryInfo = await getSingleSubCategoryInfoBySlug(categorySlug, subcategorySlug);
      if (!SubCategoryInfo)
        return Response.json({ message: "SubCategoryInfo not found" }, { status: 404 });
      return Response.json(SubCategoryInfo, { status: 200 });
    }


    const subCategoryInfo = await getAllSubCategoryInfo();
    return Response.json(subCategoryInfo, { status: 200 });

  } catch (error) {
    console.error("❌ Error fetching SubCategoryInfo:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}


export async function POST(req) {
  try {
    const body = await req.json();
    console.log("📝 Incoming SubCategoryInfo data:", body); // Debug line

    const newSubCategoryInfo = await createSubCategoryInfo(body);
    return Response.json(newSubCategoryInfo, { status: 201 });
  } catch (error) {
    console.error("❌ Error creating SubCategoryInfo:", error);
    return Response.json({ message: error.message || "Failed to create SubCategoryInfo" }, { status: 500 });
  }
}


export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (isNaN(id)) return Response.json({ message: "Invalid SubCategoryInfo ID" }, { status: 400 });

    const body = await req.json();
    const updatedSubCategoryInfo = await updateSubCategoryInfo(id, body);
    return Response.json(updatedSubCategoryInfo, { status: 200 });
  } catch (error) {
    console.error("❌ Error updating SubCategoryInfo:", error);
    return Response.json({ message: "Failed to update SubCategoryInfo" }, { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get("slug");

    if (!slug) return Response.json({ message: "Missing slug" }, { status: 400 });

    await deleteSubCategoryInfo(slug);
    return Response.json({ message: "SubCategoryInfo deleted successfully" }, { status: 200 });
  } catch (error) {
    console.error("❌ Error deleting SubCategoryInfo:", error);
    return Response.json({ message: "Failed to delete SubCategoryInfo" }, { status: 500 });
  }
}

// ========================== QUERIES ==========================

const getAllSubCategoryInfo = async () => {
  const [rows] = await db.query("SELECT * FROM subCategoryInfo");
  return rows.map((SubCategoryInfo) => ({
    ...SubCategoryInfo,
    imagesArray: SubCategoryInfo.imagesArray ? JSON.parse(SubCategoryInfo.imagesArray) : [],
  }));
};

const getSingleSubCategoryInfo = async (id) => {
  const [rows] = await db.query("SELECT * FROM subCategoryInfo WHERE id = ?", [id]);
  if (rows.length === 0) return null;
  return {
    ...rows[0],
    imagesArray: rows[0].imagesArray ? JSON.parse(rows[0].imagesArray) : [],
  };
};

const normalize = (str) =>
  slugify(str || "", { lower: true, strict: true }); // removes special characters, lowercases

const getSingleSubCategoryInfoBySlug = async (categorySlug, subcategorySlug) => {
  const formattedCategory = normalize(categorySlug);
  const formattedSubCategory = normalize(subcategorySlug);

  const [rows] = await db.query(`SELECT * FROM subCategoryInfo`);

  // Normalize the DB fields on the fly for comparison
  const match = rows.find((item) => {
    const dbCategorySlug = normalize(item.categoryName);
    const dbSubCategorySlug = normalize(item.subCategoryName);
    return dbCategorySlug === formattedCategory && dbSubCategorySlug === formattedSubCategory;
  });

  console.log('match', match);



  const [blogRows] = await db.query(
    `SELECT * FROM blogs WHERE blogCatID = ? AND blogSubCatID = ?`,
    [match.categoryId, match.subCategoryId]
  );
  const [faqsRows] = await db.query(
    `SELECT * FROM faqs WHERE categoryId = ? AND subcategoryId = ?`,
    [match.categoryId, match.subCategoryId]
  );

  if (!match) return null;
  return {
    ...match,
    imagesArray: match.imagesArray ? JSON.parse(match.imagesArray) : [],
    blogs: blogRows || [],
    faqs: faqsRows || [],
  };
};



const createSubCategoryInfo = async ({
  subCategoryTitle,
  subCategoryContent,
  categoryName,
  subCategoryName,
  categoryId,
  subCategoryId,
  imagesArray,
}) => {
  if (!subCategoryTitle || typeof subCategoryTitle !== "string") {
    throw new Error("subCategoryTitle must be a non-empty string");
  }

  const slug = slugify(subCategoryTitle, { lower: true, strict: true });

  const [result] = await db.query(
    `INSERT INTO subCategoryInfo (
      subCategoryTitle,
      subCategoryContent,
      categoryName,
      subCategoryName,
      categoryId,
      subCategoryId,
      slug,
      imagesArray
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      subCategoryTitle,
      subCategoryContent,
      categoryName,
      subCategoryName,
      categoryId,
      subCategoryId,
      slug,
      imagesArray?.length ? JSON.stringify(imagesArray) : null,
    ]
  );

  return {
    id: result.insertId,
    subCategoryTitle,
    slug,
    subCategoryContent,
  };
};


const updateSubCategoryInfo = async (
  id,
  {
    subCategoryTitle,
    subCategoryContent,
    categoryName,
    subCategoryName,
    categoryId,
    subCategoryId,
    imagesArray,
  }
) => {
  const slug = slugify(subCategoryTitle, { lower: true, strict: true });

  await db.query(
    `UPDATE subCategoryInfo SET
      subCategoryTitle = ?,
      subCategoryContent = ?,
      categoryName = ?,
      subCategoryName = ?,
      categoryId = ?,
      subCategoryId = ?,
      slug = ?,
      imagesArray = ?
    WHERE id = ?`,
    [
      subCategoryTitle,
      subCategoryContent,
      categoryName,
      subCategoryName,
      categoryId,
      subCategoryId,
      slug,
      imagesArray?.length ? JSON.stringify(imagesArray) : null,
      id,
    ]
  );

  return { id, subCategoryTitle, slug, subCategoryContent };
};

const deleteSubCategoryInfo = async (slug) => {
  await db.query("DELETE FROM subCategoryInfo WHERE slug = ?", [slug]);
  return { message: "SubCategoryInfo deleted successfully" };
};
