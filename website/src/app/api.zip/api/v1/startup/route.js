import { db } from "../../config/dbConfig";
import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";

// POST: Create default admin user on startup
export async function POST(req) {
  try {
    // 1. Check if admin already exists
    const [existingAdmins] = await db.query("SELECT * FROM users WHERE role = 'admin' LIMIT 1");
    if (existingAdmins.length > 0) {
      return NextResponse.json({ message: "Admin user already exists" }, { status: 200 });
    }

    // 2. Hash default password
    const hashedPassword = await bcrypt.hash("admin123", 10);

    // 3. Prepare default admin data
    const defaultAdmin = {
      first_name: "Admin",
      last_name: "User",
      phone_number: "9999999999",
      additional_number: null,
      email: "admin@example.com",
      gender: "Other",
      address: "Startup Lane",
      city: "System",
      password: hashedPassword,
      aadhar_no: "000000000000",
      aadhar_image: null,
      role: "admin",
    };

    // 4. Insert into database
    const [result] = await db.query(
      `INSERT INTO users 
      (first_name, last_name, phone_number, additional_number, email, gender, address, city, password, aadhar_no, aadhar_image, role)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        defaultAdmin.first_name,
        defaultAdmin.last_name,
        defaultAdmin.phone_number,
        defaultAdmin.additional_number,
        defaultAdmin.email,
        defaultAdmin.gender,
        defaultAdmin.address,
        defaultAdmin.city,
        defaultAdmin.password,
        defaultAdmin.aadhar_no,
        defaultAdmin.aadhar_image,
        defaultAdmin.role,
      ]
    );

    return NextResponse.json({
      message: "Admin user created successfully",
      user: { id: result.insertId, email: defaultAdmin.email },
    }, { status: 201 });

  } catch (error) {
    console.error("❌ Startup Admin Error:", error);
    return NextResponse.json({ message: "Failed to create admin user" }, { status: 500 });
  }
}
