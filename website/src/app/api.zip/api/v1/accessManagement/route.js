import { db } from "../../config/dbConfig";

// GET handler: Returns all records or a single record if ?role= is provided
export async function GET(req) {
  try {
    const url = new URL(req.url);
    const role = url.searchParams.get("role");

    console.log('Request URL:', req.url);
    console.log('Extracted Role:', role);

    if (!role) {
      return Response.json({ message: "Missing 'role' parameter" }, { status: 400 });
    }

    const accessRecords = await getAccessRecordsByRole(role);
    return Response.json(accessRecords, { status: 200 });

  } catch (error) {
    console.error("❌ Error fetching access record:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}


// POST handler: Expects a payload with a role and modules object.
// Inserts one record per module.
export async function POST(req) {
  try {
    const body = await req.json();
    const { role, modules } = body;
    if (!role || !modules) {
      return Response.json({ message: "Missing role or modules" }, { status: 400 });
    }
    
    await deleteAccessRecordsByRole(role);
    const results = [];
    for (const [moduleName, perms] of Object.entries(modules)) {
      const { read, write, delete: del, all } = perms;
      const [result] = await db.query(
        `INSERT INTO roleaccess (role, module, can_read, can_write, can_delete, can_all)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [role, moduleName, read, write, del, all]
      );
      results.push({ id: result.insertId, role, module: moduleName, ...perms });
    }
    return Response.json(
      { message: "Access records created", records: results },
      { status: 201 }
    );
  } catch (error) {
    console.error("❌ Error creating access record:", error);
    return Response.json({ message: "Failed to create access record" }, { status: 500 });
  }
}

// Helper functions for database operations

const getAllAccessRecords = async () => {
  const [rows] = await db.query("SELECT * FROM roleaccess");
  return rows;
};

const getAccessRecordsByRole = async (role) => {
  const [rows] = await db.query("SELECT * FROM roleaccess WHERE role = ?", [role]);
  return rows;
};

const deleteAccessRecordsByRole = async (role) => {
  await db.query("DELETE FROM roleaccess WHERE role = ?", [role]);
};
