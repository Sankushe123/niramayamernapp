import { sendEmail } from '../../utils/sendEmailInqueiry';

export async function POST(request) {
  try {
    const data = await request.json();
    const { name, email, phone, message } = data;

    if (!name || !email || !message) {
      return new Response(
        JSON.stringify({ error: 'Name, email, and message are required.' }),
        { status: 400 }
      );
    }

    const result = await sendEmail({ name, email, phone, message });

    if (!result.success) {
      return new Response(
        JSON.stringify({ error: 'Failed to send emails' }),
        { status: 500 }
      );
    }

    return new Response(
      JSON.stringify({ message: 'Message sent successfully' }),
      { status: 200 }
    );
  } catch (error) {
    console.error('API POST error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal Server Error' }),
      { status: 500 }
    );
  }
}