import { db } from "../../config/dbConfig";

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      const faq = await getSingleFAQ(parseInt(id, 10));
      if (!faq) return Response.json({ message: "FAQ not found" }, { status: 404 });
      return Response.json(faq, { status: 200 });
    }

    return Response.json(await getAllFAQs(), { status: 200 });
  } catch (error) {
    console.error("❌ Error fetching FAQs:", error);
    return Response.json({ message: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const newFAQ = await createFAQ(body);
    return Response.json(newFAQ, { status: 201 });
  } catch (error) {
    console.error("❌ Error creating FAQ:", error);
    return Response.json({ message: "Failed to create FAQ" }, { status: 500 });
  }
}

export async function PUT(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (isNaN(Number(id))) return Response.json({ message: "Invalid FAQ ID" }, { status: 400 });

    const body = await req.json();
    const updatedFAQ = await updateFAQ(parseInt(id, 10), body);
    return Response.json(updatedFAQ, { status: 200 });
  } catch (error) {
    console.error("❌ Error updating FAQ:", error);
    return Response.json({ message: "Failed to update FAQ" }, { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (isNaN(Number(id))) return Response.json({ message: "Invalid FAQ ID" }, { status: 400 });

    await deleteFAQ(parseInt(id, 10));
    return Response.json({ message: "FAQ deleted successfully" }, { status: 200 });
  } catch (error) {
    console.error("❌ Error deleting FAQ:", error);
    return Response.json({ message: "Failed to delete FAQ" }, { status: 500 });
  }
}

// Database Queries
const getAllFAQs = async () => {
  const [rows] = await db.query(`
    SELECT faqs.id, faqs.question, faqs.answer, 
           faqs.categoryId, categories.categoryName, 
           faqs.subcategoryId, subcategories.subCategoryName
    FROM faqs
    JOIN categories ON faqs.categoryId = categories.id
    JOIN subcategories ON faqs.subcategoryId = subcategories.id
  `);
  return rows;
};

const getSingleFAQ = async (id) => {
  const [rows] = await db.query(`
    SELECT faqs.id, faqs.question, faqs.answer, 
           faqs.categoryId, categories.categoryName, 
           faqs.subcategoryId, subcategories.subCategoryName
    FROM faqs
    JOIN categories ON faqs.categoryId = categories.id
    JOIN subcategories ON faqs.subcategoryId = subcategories.id
    WHERE faqs.id = ?
  `, [id]);

  if (rows.length === 0) return null;
  return rows[0];
};

const createFAQ = async ({ question, answer, categoryId, categoryName, subcategoryId, subCategoryName }) => {
  const [result] = await db.query(`
    INSERT INTO faqs (question, answer, categoryId, categoryName, subcategoryId, subCategoryName) 
    VALUES (?, ?, ?, ?, ?, ?)`,
    [question, answer, categoryId, categoryName, subcategoryId, subCategoryName]
  );
  return { id: result.insertId, question, answer, categoryId, categoryName, subcategoryId, subCategoryName };
};

const updateFAQ = async (id, { question, answer, categoryId, categoryName, subcategoryId, subCategoryName }) => {
  await db.query(`
    UPDATE faqs 
    SET question = ?, answer = ?, categoryId = ?, categoryName = ?, subcategoryId = ?, subCategoryName = ?
    WHERE id = ?`,
    [question, answer, categoryId, categoryName, subcategoryId, subCategoryName, id]
  );
  return { id, question, answer, categoryId, categoryName, subcategoryId, subCategoryName };
};

const deleteFAQ = async (id) => {
  await db.query("DELETE FROM faqs WHERE id = ?", [id]);
  return { message: "FAQ deleted successfully" };
};
